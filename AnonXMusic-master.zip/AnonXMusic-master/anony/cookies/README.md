<p align="center">
    1. Upload your <b>Netscape format</b> youtube cookies to batbin.me<br>
    2. Add <code>COOKIES_URL</code> variable in the env and enter the batbin url in the value.<br>
    <i>Note: (Multiple values should be seperated by " ")</i>
</p>

<p align="center">
    <b>or</b>
</p>

<p align="center">
    Local storage for cookies.<br>
    The file extension must be .txt and the cookie must be in <b>Netscape format.</b>
</p>
